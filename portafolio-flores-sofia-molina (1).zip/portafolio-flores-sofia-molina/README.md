# Sofía Molina · Portafolio de fotografía floral

Galería en React + Vite donde cada foto de flores se califica con corazones; las fotos se reordenan según la calificación y un botón muestra el promedio.

## Uso

```bash
npm install
npm run dev      # desarrollo
npm run build    # genera dist/
firebase deploy  # publica en Firebase Hosting
```

Fotos: dataset "flower_photos" de TensorFlow (imágenes de Flickr con licencia CC-BY).

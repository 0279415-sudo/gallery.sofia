function Footer() {
  return (
    <footer className="footerPage">
      <p className="footerName">Sofía Molina</p>
      <p>© {new Date().getFullYear()} · Todos los derechos reservados</p>
      <p className="credits">Fotos: dataset “flower_photos” de TensorFlow, imágenes de Flickr con licencia CC-BY.</p>
    </footer>
  )
}

export default Footer

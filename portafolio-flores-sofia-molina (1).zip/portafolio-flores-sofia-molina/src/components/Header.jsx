function Header() {
  return (
    <>
      <nav className="topBar">
        <span className="logo">S·M</span>
        <span className="topTag">✿ fotografía floral ✿</span>
      </nav>
      <header className="pageName">
        <div className="hero">
          <p className="heroKicker">portafolio de</p>
          <h1 className="heroName">Sofía Molina</h1>
          <p className="heroText">
            Pétalos, luz suave y pequeños jardines. Una colección de mis fotos
            favoritas de flores — califica cada una con corazones y mira cómo
            se reacomodan tus preferidas.
          </p>
        </div>
      </header>
    </>
  )
}

export default Header

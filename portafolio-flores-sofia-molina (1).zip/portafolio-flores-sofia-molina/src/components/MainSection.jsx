import Flor1 from "../assets/flor_1.jpg";
import Flor2 from "../assets/flor_2.jpg";
import Flor3 from "../assets/flor_3.jpg";
import Flor4 from "../assets/flor_4.jpg";
import Flor5 from "../assets/flor_5.jpg";
import Flor6 from "../assets/flor_6.jpg";
import Flor7 from "../assets/flor_7.jpg";
import Flor8 from "../assets/flor_8.jpg";
import Flor9 from "../assets/flor_9.jpg";
import { Rate } from "./Rate";
import Promedio from "./Promedio";
import { useState } from "react";

function MainSection() {
  const [images, setImages] = useState([
    { src: Flor1, titulo: "Tulipán rosa", rate: 0, id: 0 },
    { src: Flor2, titulo: "Campo de tulipanes", rate: 0, id: 1 },
    { src: Flor3, titulo: "Ramo de rosas", rate: 0, id: 2 },
    { src: Flor4, titulo: "Margarita rubor", rate: 0, id: 3 },
    { src: Flor5, titulo: "Rosa melocotón", rate: 0, id: 4 },
    { src: Flor6, titulo: "Tulipán fucsia", rate: 0, id: 5 },
    { src: Flor7, titulo: "Tulipanes lila", rate: 0, id: 6 },
    { src: Flor8, titulo: "Margarita al sol", rate: 0, id: 7 },
    { src: Flor9, titulo: "Girasol", rate: 0, id: 8 },
  ]);

  const editaRate = (id, newRate) => {
    const newImages = images.map((img) => {
      if (img.id == id) return { ...img, rate: newRate };
      else return img;
    });

    newImages.sort((a, b) => {
      return b.rate - a.rate;
    });

    setImages(newImages);
  };

  return (
    <main>
      <h2 className="sectionTitle">Mi colección</h2>
      <div className="mainSection">
        {images.map((img) => (
          <div className="scoreCard" key={img.id}>
            <div className="imgWrap">
              <img src={img.src} alt={img.titulo} />
            </div>
            <p className="cardTitle">{img.titulo}</p>
            <Rate editaRate={editaRate} id={img.id} rate={img.rate}></Rate>
          </div>
        ))}
      </div>
      <Promedio images={images} />
    </main>
  );
}

export default MainSection;
